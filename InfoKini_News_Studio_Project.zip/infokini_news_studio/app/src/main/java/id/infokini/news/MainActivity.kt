package id.infokini.news

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.VideoView

private val Navy = Color(0xFF080D4A)
private val Cyan = Color(0xFF13BDEB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InfoKiniApp() }
    }
}

@Composable
fun InfoKiniApp() {
    val context = LocalContext.current
    var headline by remember { mutableStateOf("Judul berita Anda di sini") }
    var reporter by remember { mutableStateOf("Reporter: InfoKini News") }
    var ticker by remember { mutableStateOf("INFO TERKINI • BERITA • INFORMASI • TERPERCAYA •") }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Pilih video atau foto dari galeri untuk memulai.") }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        videoUri = it
        if (it != null) status = "Video berhasil dipilih. Pratinjau tersedia di bawah."
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        imageUri = it
        if (it != null) status = "Foto berhasil dipilih."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Color(0xFF10164F),
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("INFO", color = Cyan, fontSize = 27.sp, fontWeight = FontWeight.Black)
                Text("KINI", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(8.dp))
                Text("NEWS STUDIO", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Text("STUDIO BERITA DIGITAL", color = Color.LightGray, fontSize = 12.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF11194F))) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("PRATINJAU SIARAN", color = Cyan, fontWeight = FontWeight.Bold)
                    if (videoUri != null) {
                        AndroidView(
                            factory = { VideoView(it).apply { setVideoURI(videoUri); setOnPreparedListener { p -> p.isLooping = true; start() } } },
                            update = { it.setVideoURI(videoUri) },
                            modifier = Modifier.fillMaxWidth().height(190.dp)
                        )
                    } else {
                        Box(Modifier.fillMaxWidth().height(190.dp).background(Color(0xFF05082C), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            Text("VIDEO INFO KINI NEWS", color = Color.White.copy(alpha = .65f), fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(headline, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(reporter, color = Color.LightGray, fontSize = 12.sp)
                    Text("infokini.news", color = Cyan, fontWeight = FontWeight.Bold)
                    Text(ticker, color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF101010)).padding(8.dp))
                }
            }
            OutlinedTextField(headline, { headline = it }, label = { Text("Judul berita") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(reporter, { reporter = it }, label = { Text("Nama reporter") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(ticker, { ticker = it }, label = { Text("Running text / teks berjalan") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.weight(1f)) { Text("Pilih Video") }
                OutlinedButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Pilih Foto") }
            }
            if (imageUri != null) Text("Foto dipilih: ${imageUri?.lastPathSegment ?: "1 foto"}", color = Color.LightGray)
            Text(status, color = Color(0xFFB7DDF2), fontSize = 12.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF11194F))) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("CATATAN", color = Cyan, fontWeight = FontWeight.Bold)
                    Text("Versi proyek ini menyediakan editor naskah, pemilihan media, dan pratinjau dasar. Ekspor MP4 dengan grafis yang menyatu ke video serta siaran langsung YouTube/TikTok/Facebook belum diaktifkan pada build ini.", color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }
}
